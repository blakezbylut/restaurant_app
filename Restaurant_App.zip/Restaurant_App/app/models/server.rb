class Server < ActiveRecord::Base
  has_secure_password
end
